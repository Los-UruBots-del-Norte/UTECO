module.exports = RED => {
    const socket = require("../connection").socket;
    const ConnectionHelper = require("../connectionHelper");
    const EventPubSub = require("../eventPubSub");
    let lastReset = 0;

    const events = new EventPubSub();

    function resetNodeState(ch) {
        if (lastReset + 100 > Date.now()) {
            return;
        }

        lastReset = Date.now();
        ch.emit(null, "/robot/face/stop");
    }

    function WaitForFace(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.path = "/robot/face/start";
        node.waitingNode = null;

        const ch = new ConnectionHelper(socket, node);

        node.on("input", msg => {
            node.waitingNode = msg;
            node.status({ fill: "blue", shape: "dot", text: node.type + ".waiting" });

            // wait some time to prevent a race condition with _set_awareness
            node.timeout = setTimeout(() => {
                ch.emit();
            }, 250);
        });

        ch.socket.on("/event/face/detected", () => {
            if (!node.waitingNode) {
                return;
            }

            node.send(node.waitingNode);
            node.waitingNode = null;

            node.status({});
        });

        node.on("close", (removed, done) => {
            resetNodeState(ch);
            done();
        });

        events.subscribe(EventPubSub.RESET_NODE_STATE, () => {
            resetNodeState(ch);

            waitingNode = null;
            node.status({});
        });
    }
    RED.nodes.registerType("Wait for face", WaitForFace);
}