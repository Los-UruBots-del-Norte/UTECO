module.exports = RED => {
    const socket = require("../connection").socket;
    const ConnectionHelper = require("../connectionHelper");
    const EventPubSub = require("../eventPubSub");
    let lastReset = 0;

    const events = new EventPubSub();

    function resetNodeState(ch) {
        if (lastReset + 100 > Date.now()) {
            return;
        }

        lastReset = Date.now();
        ch.emit(null, "/robot/speech-recognition/stop");
    }

    function WaitForKeyword(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.path = "/robot/speech-recognition/start";
        node.waitingNode = null;

        const ch = new ConnectionHelper(socket, node);

        node.on("input", msg => {
            node.waitingNode = msg;
            node.status({ fill: "blue", shape: "dot", text: node.type + ".waiting" });

            ch.emit([config.keywords, config.language, config.threshold]);
        });

        ch.socket.on("/event/speech/recognized", keyword => {
            if (!node.waitingNode || !config.keywords.includes(keyword)) {
                return;
            }

            const output = new Array(config.keywords.length).fill(null);
            const index = config.keywords.indexOf(keyword);

            output[index] = node.waitingNode;

            node.send(output);
            node.waitingNode = null;

            node.status({});
        });

        node.on("close", (removed, done) => {
            resetNodeState(ch);
            done();
        });

        events.subscribe(EventPubSub.RESET_NODE_STATE, () => {
            resetNodeState(ch);

            waitingNode = null;
            node.status({});
        });
    }
    RED.nodes.registerType("Wait for keyword", WaitForKeyword);
}