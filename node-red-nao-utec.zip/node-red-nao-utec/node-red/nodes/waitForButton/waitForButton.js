module.exports = RED => {
    const socket = require("../connection").socket;
    const ConnectionHelper = require("../connectionHelper");
    const EventPubSub = require("../eventPubSub");

    const events = new EventPubSub();

    function getMapping(node) {
        const mapping = {
            "/event/Head": RED._(node.type + ".buttons.head"),
            "/event/LHand/Touch/Back": RED._(node.type + ".buttons.leftHand"),
            "/event/RHand/Touch/Back": RED._(node.type + ".buttons.rightHand"),
            "/event/Bumper/FrontLeft": RED._(node.type + ".buttons.leftBumper"),
            "/event/Bumper/FrontRight": RED._(node.type + ".buttons.rightBumper"),
            "/event/Bumper/Back": RED._(node.type + ".buttons.backBumper")
        };

        // remove (***) from each entry
        Object.keys(mapping).forEach(m => {
            if (mapping[m].includes("(")) {
                mapping[m] = mapping[m].split("(")[0].trim();
            }
        });

        return mapping;
    }

    function WaitForButton(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.path = "/robot/wait/button";
        node.waitingNode = null;
        const mapping = getMapping(node);

        const ch = new ConnectionHelper(socket, node);

        node.on("input", msg => {
            node.waitingNode = msg;
            node.status({ fill: "blue", shape: "dot", text: RED._(node.type + ".waiting").replace("{}", mapping[config.button]) });
        });

        ch.socket.on(config.button, () => {
            if (!node.waitingNode) {
                return;
            }

            node.waitingNode.payload = {
                "value": mapping[config.button]
            };

            node.send(node.waitingNode);
            node.waitingNode = null;

            node.status({});
        });

        events.subscribe(EventPubSub.RESET_NODE_STATE, () => {
            waitingNode = null;
            node.status({});
        });
    }
    RED.nodes.registerType("Wait for button", WaitForButton);
}