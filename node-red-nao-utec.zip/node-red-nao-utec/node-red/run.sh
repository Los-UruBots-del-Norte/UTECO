#!/bin/sh

cp settingsTemplate.js /data/settings.js

nodemon --watch /nodes/ \
-e js,html,py,json \
--exec "rm -rf nodes/* && cp -R /nodes . && npm install --no-audit --progress=false nodes/ && node-red start --userDir /data $FLOWS"
