#!/bin/sh

# build rest-server container
docker build -t rest-server rest-server/

# build mosquitto container
docker build -t mosquitto mosquitto/

# build Node-RED container
docker build -t node-red node-red/

# create data folder for Node-RED
mkdir -p node-red/data
mkdir -p node-red/data-nao

# give container write permissions
chmod 777 node-red/data
chmod 777 node-red/data-nao
chown 1000 node-red/data
chown 1000 node-red/data-nao

# build ESP container
#docker build -t esp esp/

# build mdns container
docker build -t mdns mdns/
