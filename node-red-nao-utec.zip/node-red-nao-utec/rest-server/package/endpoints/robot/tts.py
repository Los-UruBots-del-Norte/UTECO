import logging

from flask import request, Response

from ...server import app, socketio
from ...pepper.connection import tts
from ...decorator import log
from ...mqtt import socketio_wrapper

logger = logging.getLogger(__name__)

@socketio.on("/robot/tts/say")
@app.route("/robot/tts/say", methods=["POST"])
@log("/robot/tts/say")
def say(data = None):
    try:
        if data:
            text, language = data
        else:
            text = request.json["text"]
            language = request.json["language"]

        tts.setLanguage(language)
        future = tts.say(str(text), _async=True)
        future.addCallback(tts_finished)

        return Response(status=200)
    except Exception as e:
        logger.error(e)
        return Response(str(e), status=400)

@socketio.on("/robot/tts/volume")
@app.route("/robot/tts/volume", methods=["POST"])
@log("/robot/tts/volume")
def set_tts_volume(volume = None):
    if not volume:
        volume = request.json["volume"]
    
    tts.setVolume(volume)

    return Response(status=200)

@app.route("/robot/tts/volume")
@log("/robot/tts/volume")
def get_tts_volume():
    tts_volume = tts.getVolume()
    
    if not tts_volume:
        tts_volume = "-"

    return Response(str(tts_volume), status=200)

def tts_finished(future):
    logger.debug("TTS finished")

    # reset language to English
    tts.setLanguage("English")

    socketio_wrapper("/event/tts/finished")
