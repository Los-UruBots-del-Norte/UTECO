import logging
import traceback

from flask import request, Response
from flask_socketio import emit

from ...server import app, socketio
from ...decorator import log
from ...pepper.connection import speech_recognition

logger = logging.getLogger(__name__)
speech_threshold = 1

@socketio.on("/robot/speech-recognition/start")
@app.route("/robot/speech-recognition/start", methods=["POST"])
@log("/robot/speech-recognition/start")
def start_speech_recognition(data = None):
    try:
        if data:
            word, language, threshold = data
        else:
            word = request.json["word"]
            language = request.json["language"]
            threshold = request.json["threshold"]

        global speech_threshold
        speech_threshold = float(threshold)

        speech_recognition.pause(True)

        # I'm not proud of this
        # fix to prevent "A grammar named "modifiable_grammar" already exists."
        speech_recognition.setLanguage("Spanish")
        speech_recognition.setLanguage("English")

        speech_recognition.setLanguage(language)
        speech_recognition.setVocabulary(word, False)
        speech_recognition.setAudioExpression(True)
        speech_recognition.setVisualExpression(True)

        speech_recognition.pause(False)
        speech_recognition.subscribe("speech_recognition")

        return Response(status=200)
    except Exception as e:
        logger.error(e)
        logger.error(traceback.format_exc())

        return Response(str(e), status=400)

@socketio.on("/robot/speech-recognition/stop")
@app.route("/robot/speech-recognition/stop", methods=["POST"])
@log("/robot/speech-recognition/stop")
def stop_speech_recognition():
    try:
        speech_recognition.pause(True)
        speech_recognition.unsubscribe("speech_recognition", _async=True)

        return Response(status=200)
    except Exception as e:
        logger.debug(e)
        return Response(str(e), status=400)

def on_word_recognized(data):
    global speech_threshold

    for word in data:
        if word[1] > speech_threshold:
            stop_speech_recognition()

            with app.test_request_context():
                emit("/event/speech/recognized", word[0], broadcast=True, namespace="/")
