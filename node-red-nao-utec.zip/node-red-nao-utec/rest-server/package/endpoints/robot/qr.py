import logging
import json

from flask import request, Response
from flask_socketio import emit
from distutils.util import strtobool

from ...server import app, socketio
from ...pepper.connection import barcode
from ...config import CAMERA_UPDATE_INTERVAL
from ...decorator import log
from .awareness import _set_awareness

logger = logging.getLogger(__name__)
all_input = False

@socketio.on("/robot/qr/start")
@app.route("/robot/qr/start", methods=["POST"])
@log("/robot/qr/start")
def start_qr_detection(allow_all_input=None):
    if not allow_all_input:
        allow_all_input = request.json["allow_all_input"]

    global all_input
    all_input = strtobool(allow_all_input)

    _set_awareness(False)
    barcode.setActiveCamera(0) # Head camera
    barcode.setResolution(2) # 640x480
    barcode.setFrameRate(1000 / CAMERA_UPDATE_INTERVAL)

    barcode.subscribe("barcode_detection", 100, 0)

    return Response(status=200)

@socketio.on("/robot/qr/stop")
@app.route("/robot/qr/stop", methods=["POST"])
@log("/robot/qr/stop")
def stop_qr_detection():
    try:
        _set_awareness(True)
        barcode.unsubscribe("barcode_detection", _async=True)

        return Response(status=200)
    except Exception as e:
        logger.warning(e)
        return Response(str(e), status=400)

def on_qr_code_deteced(data):
    global all_input

    try:
        data = data[0]
        stop = False

        for qr in data:
            qr = qr[0]

            if "id" in qr:
                data = json.loads(qr)
                emit("/event/qr/detected", data["id"], broadcast=True, namespace="/")
                stop = True
                break
            else:
                if all_input:
                    emit("/event/qr/detected", qr, broadcast=True, namespace="/")
                    stop = True
                    break
                else:
                   logger.info("Wrong QR-Code format detected")
                
        if stop:
            stop_qr_detection()
    except Exception as e:
        logger.error(e)
