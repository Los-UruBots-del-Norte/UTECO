from sys import flags
from flask import render_template

from ..server import app
from ..config import FLASK_IP, FLASK_PORT, EASTER_EGGS
from ..pepper.connection import connection_type
from .robot.battery import get_battery_percentage
from .robot.audio import get_general_volume
from .robot.system import get_name
from .robot.tts import get_tts_volume
from .esp.esp import get_connection_status
from .esp.thermal_camera import get_camera_status

@app.route("/debug")
def get_debug_page():
    battery_percentage = get_battery_percentage().data.decode("UTF-8")
    general_volume = get_general_volume().data.decode("UTF-8")
    tts_volume = get_tts_volume().data.decode("UTF-8")
    robot_name = get_name().data.decode("UTF-8")

    try:
        tts_volume = int(float(tts_volume) * 100)
    except ValueError:
        if "Dummy" in tts_volume:
            tts_volume = "-"

    if "Dummy" in battery_percentage:
        battery_percentage = "-"
    if "Dummy" in general_volume:
        general_volume = 0
    
    return render_template("debug.html",
        robot_name = robot_name,
        flask_ip = "{}:{}".format(FLASK_IP, FLASK_PORT),
        connection_type=connection_type,
        battery=battery_percentage,
        general_volume=general_volume,
        tts_volume=tts_volume,
        esp_connection = "connected" if get_connection_status() else "disconnected",
        camera_status=get_camera_status(),
        easter_eggs=EASTER_EGGS)
