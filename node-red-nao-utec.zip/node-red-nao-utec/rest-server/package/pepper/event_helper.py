from .connection import memory
from ..config import FLASK_IP, FLASK_PORT

def send_event(name, value = None):
    memory.declareEvent(name)
    memory.raiseEvent(name, value)

send_event("update_event_list", "http://{}:{}/pepper".format(FLASK_IP, FLASK_PORT))
