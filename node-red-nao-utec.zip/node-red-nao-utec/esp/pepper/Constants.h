#define DEBUG 10
#define INFO 20
#define WARNING 30
#define ERROR 40
