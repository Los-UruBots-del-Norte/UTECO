## Setup
1. Install Docker
2. `./buildContainers.sh`
3. `docker-compose up`
4. open `http://<IP_ADDRESS>:PORT` in the browser, see *Configuration* below; with PORT being 1880/1881 depending on the robot and IP_ADDRESS being the one of the machine where the containers run (NOT a robot IP!) - use *localhost* if running on your own machine

## Configuration
Ports and IP addresses of the robots are configured in the `.env` file

## Network Troubleshooting
In case there are troubles with feedback from the robot towards Node-RED, i.e. things like face and speech recognition don't work *and you are running this setup in a Virtual Machine*, make sure to use a *network bridge* instead of *NAT* (switchable in the VM's settings).